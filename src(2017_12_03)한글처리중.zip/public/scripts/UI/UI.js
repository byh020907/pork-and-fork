"use strict"
class UIButton extends UIComponent {

  constructor(texture, x, y, width, height, buttonListener) {
    super(texture, x, y, width, height);
    this.buttonListener = buttonListener;
    this.inside = false;
    this.pressed = false;
  }

  update() {
    if (hitTestPoint(this.collision, mousePos)) {
      if (!this.inside) {
        this.buttonListener.entered(this);
      }
      this.inside = true;

      if (!this.pressed && isMouseDown(1)) {
        this.buttonListener.pressed(this);
        this.pressed = true;
      } else if (this.pressed && !isMouseDown(1)) {
        this.buttonListener.released(this);
        this.pressed = false;
      }
    } else {
      if (this.inside) {
        this.buttonListener.exited(this);
        this.pressed = false;
      }
      this.inside = false;
    }

  }

}

var input={
  cho:['r','R','s','e','E','f','a','q','Q','t','T','d','w','W','c','z','x','v','g'],
  jung:["k", "o", "i", "O", "j", "p", "u", "P", "h", "hk", "ho", "hl", "y", "n", "nj", "np", "nl", "b", "m", "ml", "l"],
  jong:["","r", "R", "rt", "s", "sw", "sg", "e", "f", "fr", "fa", "fq", "ft", "fx", "fv", "fg", "a", "q", "qt", "t", "T", "d", "w", "c", "z", "x", "v", "g"]
}

var hangul = {
  cho: ['ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'],
  jung: ['ㅏ', 'ㅐ', 'ㅑ', 'ㅒ', 'ㅓ', 'ㅔ', 'ㅕ', 'ㅖ', 'ㅗ', 'ㅘ', 'ㅙ', 'ㅚ', 'ㅛ', 'ㅜ', 'ㅝ', 'ㅞ', 'ㅟ', 'ㅠ', 'ㅡ', 'ㅢ', 'ㅣ'],
  jong: ['', 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄹ', 'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ', 'ㅁ', 'ㅂ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ']
};

console.log(Hangul.a(['ㄱ','ㅅ']));

/**
 * @param String h : 영어값
 * @return 영어에 해당하는 한글 값
 */
function getHangul(h){
  for(let i=0;i<input.cho.length;i++){
    if(input.cho[i]==h)
      return hangul.cho[i];
  }

  for(let i=0;i<input.jung.length;i++){
    if(input.jung[i]==h)
      return hangul.jung[i];
  }

  return -1;
}

function isHangul(h){
  for(let i=0;i<input.cho.length;i++){
    if(input.cho[i]==h)
      return true;
  }

  for(let i=0;i<input.jung.length;i++){
    if(input.jung[i]==h)
      return true;
  }

  return false;
}

class UICursor extends GameObject{
  constructor(owner){
    super();
    this.owner=owner;
    this.body=new UIBody(this);
    this.body.pos.x=owner.body.pos.x;
    this.body.pos.y=owner.body.pos.y;
    this.body.width=10;
    this.body.height=owner.body.height;
    this.model=new Model(this);
  }

  render(pMtrx){
    super.render(pMtrx);

  }

  update(){
  }

  setCurrentPos(currentCursorIndex,display){
    var total=0;
    for(let i=0;i<currentCursorIndex;i++){
      total+=display.textCtx.measureText(this.owner.text.charAt(i)).width;
    }

    this.body.pos.x=this.owner.getX()+total;

  }
}

class UITextField extends UIButton {
  constructor(texture, x, y, width, height, buttonListener) {
    super(texture, x, y, width, height, buttonListener);
    this.isFocus=false;
    this.isHangulMode = false;
    this.text = "";
    this.buffer = [];
    this.shortBuffer=[];
    //현재 커서위치를 을 기준 좌우로 나누는 버퍼
    this.leftBuffer = [];
    this.rightBuffer = [];

    this.currentPushIndex=0;
    this.currentCursorIndex=0;
    this.cursor=new UICursor(this);
  }

  keyDown(e) {
    if(!this.isFocus)
      return;
    if (e.keyCode == 21) {
      this.isHangulMode = !this.isHangulMode;
      return;
    }
    //만약 영어 자판에 해당하면
    if(65<=e.keyCode&&e.keyCode<=90){
      let char=e.key;
      if (this.isHangulMode) {
        char=getHangul(e.key);
      }
      this.buffer.splice(this.currentPushIndex,0,char);
      this.currentPushIndex++;
      this.text=Hangul.a(this.buffer);
    }else{
      switch (e.key) {

        case "Backspace":if(this.currentPushIndex>0){
                            let a=this.text.substring(0,this.currentCursorIndex-1);
                            let b=this.text.substring(this.currentCursorIndex-1,this.currentCursorIndex);
                            let c=this.text.substring(this.currentCursorIndex,this.text.length);
                            this.text=a+c;
                            this.buffer=Hangul.d(this.text);
                            this.currentPushIndex-=Hangul.d(b).length;
                            if(this.currentPushIndex<0)
                              this.currentPushIndex=0;
                          }break;
        case "ArrowRight":if(this.currentPushIndex<this.buffer.length){
                            //커서위치를 기준으로 오른쪽의 맨첫번째 요소의 위치의 길이를 알아낸다.
                            let temp=Hangul.d(Hangul.a(this.rightBuffer),true);
                            let delNum=temp[0].length;
                            if(this.currentPushIndex+delNum<this.buffer.length)
                              this.currentPushIndex+=delNum;
                            else
                              this.currentPushIndex=this.buffer.length-1;
                          }break;
        case "ArrowLeft":if(this.currentCursorIndex>0){
                            //커서위치를 기준으로 왼쪽의 맨마지막 요소의 위치의 길이를 알아낸다.
                            let temp=Hangul.d(Hangul.a(this.leftBuffer),true);
                            let delNum=temp[temp.length-1].length;
                            if(this.currentPushIndex-delNum>=0)
                              this.currentPushIndex-=delNum;
                            else
                              this.currentPushIndex=0;
                          }break;
        case "Shift":break;
        case "Control":break;
        case "Alt":break;
        case "Tab":break;
        case "F1":case "F2":case "F3":case "F4":case "F5":case "F6":case "F7":case "F8":case "F9":case "F10":case "F11":case "F12":break;
        default:{
          this.buffer.splice(this.currentPushIndex,0,e.key);
          this.currentPushIndex++;
        }break;

      }
    }

    // 지금까지 알아낸 버그는 중간에 글자가 결합될수있도록 커서를 옮긴후 타자를 치면 그냥 합쳐저 버리는 오류였다.
    // 이 오류는 내가 버퍼를 2차원 배열이 아니라 1차원 배열을 사용하기 때문이고 이것을 내일 해결하면 될듯 싶다.
    this.leftBuffer=[];
    this.rightBuffer=[];
    //0 ~ this.currentPushIndex
    for(let i=0;i<this.currentPushIndex;i++){
      this.leftBuffer.push(this.buffer[i]);
    }
    //this.currentPushIndex ~ this.buffer.length
    for(let i=this.currentPushIndex;i<this.buffer.length;i++){
      this.rightBuffer.push(this.buffer[i]);
    }

    let lengthBuffer=Hangul.d(Hangul.a(this.leftBuffer),true);
    this.currentCursorIndex=lengthBuffer.length;
  }

  keyUp(e) {}

  update() {
    super.update();
    this.cursor.update();
  }

  render(display, xOffset, yOffset) {
    super.render(display, xOffset, yOffset);
    display.textCtx.save();
    display.textCtx.font = (this.body.height * 0.8) + "px Verdana";
    //text rendering
    display.fillText(this.text, xOffset + this.getX(), yOffset + this.getY() + this.body.height / 1.2);
    var s="";
    for(let i=0;i<this.buffer.length;i++){
      s+=this.buffer[i];
    }
    display.fillText(s, xOffset + this.getX(), yOffset + this.getY() - this.body.height / 1.2);
    this.cursor.render(display.getProjection());
    this.cursor.setCurrentPos(this.currentCursorIndex,display);
    display.textCtx.restore();
  }
}

class UIList extends UIPanel {
  constructor(texture, x, y, width, height) {
    super(texture, x, y, width, height);
  }

  addComponent(component) {
    component.init(this);
    component.setX(0);
    component.setY(0);
    var result = 0;
    for (var c of this.components) {
      result += c.body.height;
    }
    component.body.pos.y += result;
    this.components.push(component);
  }

  deleteComponent(index) {
    this.components.splice(index, 1);
    for (var i = 0; i < this.components.length; i++) {
      let component = this.components[i];
      component.setX(0);
      component.setY(0);
      var result = 0;
      for (var j = 0; j < i; j++) {
        let c = this.components[j];
        result += c.body.height;
      }
      component.body.pos.y += result;
    }

  }

}
