"use strict"

class Sprite{
  constructor(spriteSheet,sx,sy,fx,fy){
    this.spriteSheet=spriteSheet;
    this.sx=sx;
    this.sy=sy;
    this.fx=fx;
    this.fy=fy;
  }
}
