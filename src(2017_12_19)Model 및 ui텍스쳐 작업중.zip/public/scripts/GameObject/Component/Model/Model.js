"use strict"

class Model extends Component{
  constructor(owner){
    super(owner);

    this.isFlipped=false;

  }

  render(pMtrx,body) {}

}
